from dataclasses import dataclass

@dataclass
class Student:
    student_id: int
    name: str
    department: str

class Node:
    def __init__(self, record):
        self.record, self.left, self.right, self.height = record, None, None, 1

class BST:
    def __init__(self): self.root = None
    def insert(self, r):
        if not self.root:
            self.root = Node(r); return 0
        n, c = self.root, 0
        while True:
            c += 1
            if r.student_id < n.record.student_id:
                if n.left is None: n.left = Node(r); return c
                n = n.left
            elif r.student_id > n.record.student_id:
                if n.right is None: n.right = Node(r); return c
                n = n.right
            else: return c
    def search(self, key):
        n, c = self.root, 0
        while n:
            c += 1
            if key == n.record.student_id: return n.record, c
            n = n.left if key < n.record.student_id else n.right
        return None, c
    def height(self):
        def h(n): return 0 if n is None else 1 + max(h(n.left), h(n.right))
        return h(self.root)
    def traverse(self, order):
        out = []
        def walk(n):
            if not n: return
            if order == "preorder": out.append(n.record.student_id)
            walk(n.left)
            if order == "inorder": out.append(n.record.student_id)
            walk(n.right)
            if order == "postorder": out.append(n.record.student_id)
        walk(self.root); return out

class AVL:
    def __init__(self): self.root = None
    def ht(self, n): return n.height if n else 0
    def update(self, n): n.height = 1 + max(self.ht(n.left), self.ht(n.right))
    def bf(self, n): return self.ht(n.left) - self.ht(n.right)
    def right(self, y):
        x, t = y.left, y.left.right
        x.right, y.left = y, t
        self.update(y); self.update(x); return x
    def left(self, x):
        y, t = x.right, x.right.left
        y.left, x.right = x, t
        self.update(x); self.update(y); return y
    def insert(self, r):
        count = [0]
        def add(n):
            if n is None: return Node(r)
            count[0] += 1
            if r.student_id < n.record.student_id: n.left = add(n.left)
            elif r.student_id > n.record.student_id: n.right = add(n.right)
            else: return n
            self.update(n); b = self.bf(n)
            if b > 1 and r.student_id < n.left.record.student_id: return self.right(n)
            if b < -1 and r.student_id > n.right.record.student_id: return self.left(n)
            if b > 1 and r.student_id > n.left.record.student_id:
                n.left = self.left(n.left); return self.right(n)
            if b < -1 and r.student_id < n.right.record.student_id:
                n.right = self.right(n.right); return self.left(n)
            return n
        self.root = add(self.root); return count[0]
    def search(self, key):
        n, c = self.root, 0
        while n:
            c += 1
            if key == n.record.student_id: return n.record, c
            n = n.left if key < n.record.student_id else n.right
        return None, c
    def height(self): return self.ht(self.root)
    def inorder(self):
        out = []
        def walk(n):
            if n: walk(n.left); out.append(n.record.student_id); walk(n.right)
        walk(self.root); return out

class LinearHash:
    def __init__(self, capacity=67):
        self.capacity, self.table, self.collisions = capacity, [None]*capacity, 0
    def insert(self, r):
        home = r.student_id % self.capacity
        probes = 0
        for step in range(self.capacity):
            i = (home + step) % self.capacity
            if self.table[i] is None:
                self.table[i] = r; return probes
            if self.table[i].student_id == r.student_id: return probes
            probes += 1; self.collisions += 1
        raise RuntimeError("Hash table full")
    def search(self, key):
        home, c = key % self.capacity, 0
        for step in range(self.capacity):
            r = self.table[(home + step) % self.capacity]
            if r is None: return None, c
            c += 1
            if r.student_id == key: return r, c
        return None, c

ids = [1042,1017,1093,1008,1064,1025,1111,1031,1078,1050,1003,1086,1022,1104,1047,1012,1069,1038,1099,1055,1006,1081,1029,1108,1044,1019,1072,1034,1090,1059,1001,1089,1020,1101,1049,1014,1061,1036,1096,1052]
names = ["Aarav","Anaya","Kabir","Diya","Ishaan","Meera","Rohan","Sara","Arjun","Nisha","Vivaan","Aditi","Reyansh","Kavya","Advik","Ira","Krish","Tara","Ayaan","Myra","Dev","Kiara","Neil","Riya","Om","Saanvi","Yash","Pihu","Atharv","Zoya","Manav","Jiya","Rudra","Avni","Dhruv","Anvi","Kunal","Mahi","Samar","Veda"]
records = [Student(x, names[i], ["AIML","CSE","ECE","EEE"][i%4]) for i,x in enumerate(ids)]
bst, avl, ht = BST(), AVL(), LinearHash()
bi, ai = [], []
for r in records:
    bi.append(bst.insert(r)); ai.append(avl.insert(r)); ht.insert(r)

def search_report(label, key):
    print(f"\\n{label}: {key}")
    for name, ds in [("BST",bst),("AVL",avl),("Hash",ht)]:
        found, count = ds.search(key)
        print(f"{name}: {'FOUND '+found.name if found else 'NOT FOUND'}; comparisons/probes={count}")

print("ALGORITHM BATTLE — STUDENT RECORD SEARCH")
print("Initial records:", len(records))
print("BST height:", bst.height(), "| AVL height:", avl.height())
print("Hash collisions during initial insertion:", ht.collisions)
print(f"Average BST insertion comparisons: {sum(bi)/len(bi):.2f}")
print(f"Average AVL insertion comparisons: {sum(ai)/len(ai):.2f}")
print("\\nBST inorder:", bst.traverse("inorder"))
print("BST preorder:", bst.traverse("preorder"))
print("BST postorder:", bst.traverse("postorder"))
print("AVL inorder:", avl.inorder())
search_report("SUCCESSFUL SEARCH", ids[17])
search_report("UNSUCCESSFUL SEARCH", 9999)
new = Student(1120, "NewStudent", "AIML")
print("\\nINSERT ID 1120")
print("BST insertion comparisons:", bst.insert(new))
print("AVL insertion comparisons:", avl.insert(new))
before = ht.collisions
ht.insert(new)
print("Hash collisions for new insertion:", ht.collisions-before)
search_report("SEARCH AFTER INSERTION", 1120)
print("\\nFinal BST height:", bst.height(), "| Final AVL height:", avl.height())
print("\\nInterpretation: Hashing is usually efficient for exact-key lookup; AVL gives guaranteed logarithmic search; ordinary BST depends on insertion order.")
