# CLA-2 Assignment: Algorithm Battle — Which Data Structure Wins?

## Part A — Problem Selection

**Application: Student Record Search.** A college stores student ID, name and department. Staff and students need to retrieve a record using its unique Student ID.

**Problem:** Searching an unsorted list can require checking every record. This becomes slow as the number of students grows.

**Why efficient searching is needed:** Student IDs are used frequently to locate records. Fast lookup saves time and improves responsiveness.

**Why these structures?**
- **BST:** Maintains keys in an ordered tree and supports sorted inorder traversal.
- **AVL:** A self-balancing BST that prevents the tree from becoming excessively skewed.
- **Hashing:** Maps a Student ID to a table index and supports fast exact-key lookup. Linear probing handles collisions.

## Part B — Implementation

The Python program in `src/main.py` inserts the same 40 unique records, in the same order, into all three data structures.

1. **BST:** Smaller IDs go left; larger IDs go right. Search follows the same comparisons. Inorder, preorder and postorder traversals are implemented.
2. **AVL:** Uses BST rules and stores node heights. Balance factor = height(left) − height(right). LL, RR, LR and RL rotations restore balance.
3. **Hashing:** Hash function is `StudentID % 67`. If a slot is occupied, linear probing checks the next slot, wrapping around when needed.

## Part C — Mini Experiment

The program performs:
- Successful search for an ID in the dataset.
- Unsuccessful search for ID `9999`.
- Insertion of a new record, ID `1120`.
- A search for ID `1120` to verify insertion.

Run `python src/main.py` and record the values printed by your own execution. The program calculates comparisons, probes, heights and collisions.

### Observation table — fill using your actual program output

| Parameter | BST | AVL | Hashing |
|---|---:|---:|---:|
| Successful search comparisons/probes | ___ | ___ | ___ |
| Unsuccessful search comparisons/probes | ___ | ___ | ___ |
| Insertion comparisons/probes for ID 1120 | ___ | ___ | ___ |
| Height after initial 40 records | ___ | ___ | N/A |
| Height after inserting ID 1120 | ___ | ___ | N/A |
| Collisions during initial insertion | N/A | N/A | ___ |
| Collisions for ID 1120 insertion | N/A | N/A | ___ |
| Traversals | Inorder, preorder, postorder | Inorder | Not applicable |

## Part D — Algorithm Battle

| Parameter | BST | AVL | Hashing |
|---|---|---|---|
| Search complexity | Average O(log n), worst O(n) | O(log n) worst case | Average O(1), worst O(n) |
| Insertion | Average O(log n), worst O(n) | O(log n), includes rotations | Average O(1), may probe |
| Height | Depends on insertion order | Kept balanced | Not applicable |
| Collision handling | Not applicable | Not applicable | Linear probing |
| Ordered traversal | Yes | Yes | No |
| Main advantage | Simple implementation | Predictable search depth | Fast exact-key lookup |
| Main limitation | Can become skewed | More complex insertion | Performance depends on collisions/load factor |

**Analysis:** A smaller search comparison/probe count means fewer inspected keys in this experiment. Compare the printed BST and AVL heights to see the effect of balancing. Hash collisions depend on the hash function, capacity and input IDs. This experiment describes this dataset and insertion order; it does not prove one structure always wins.

## Part E — Final Verdict

**Recommended winner for exact Student-ID lookup: Hashing with Linear Probing.**

Student Record Search mainly requires finding a record from an exact unique ID. Hashing normally provides average O(1) lookup and insertion when the table is appropriately sized and the load factor is controlled.

Support the verdict with your measured output:
- Successful search probes: ___
- Unsuccessful search probes: ___
- Initial hash collisions: ___
- BST height: ___
- AVL height: ___

AVL is a strong alternative when ordered traversal and guaranteed O(log n) worst-case search are important. A normal BST is simpler but its performance depends on insertion order.

**Conclusion:** Hashing is recommended for fast exact ID lookup in this application. AVL is preferable when ordered operations are also required.

## Viva Preparation

1. **What is a BST?** A binary tree where smaller keys are stored left and larger keys right.
2. **Why can a BST become slow?** Unfavourable insertion order can make it skewed, with height close to n.
3. **What is an AVL tree?** A self-balancing BST whose node balance factors are −1, 0 or +1 after rebalancing.
4. **Name AVL rotations.** LL, RR, LR and RL.
5. **What is hashing?** A function maps a key to a table index.
6. **What is a collision?** Different keys map to the same index.
7. **What is linear probing?** Check the next slot sequentially when a collision occurs.
8. **What is load factor?** Number of stored records divided by table capacity.
9. **Why does hashing not give sorted traversal?** Slots are assigned by hash values, not key order.
10. **Which structure wins?** Hashing for exact ID lookup; AVL when ordered operations and worst-case logarithmic search matter.

## Submission Checklist
1. Run the program and verify the output.
2. Fill the observation table with your own measured values.
3. Capture a screenshot of the output.
4. Push the folder to GitHub.
5. Submit the GitHub repository URL and report through Google Classroom.

**Academic honesty:** Do not submit fabricated experimental values. Understand and explain your implementation during the viva.
