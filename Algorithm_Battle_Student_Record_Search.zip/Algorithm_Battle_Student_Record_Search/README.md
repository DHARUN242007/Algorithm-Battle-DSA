# Algorithm Battle — Student Record Search

A Python CLA-2 project comparing:
1. Binary Search Tree (BST)
2. AVL Tree
3. Hash table using Linear Probing

## Run
Requires Python 3.10+ and no external packages.

```bash
python src/main.py
```

The program inserts the same 40 unique Student IDs into all three structures, tests successful and unsuccessful searches, inserts ID 1120, and reports comparisons, tree heights, traversals, and hash collisions.

**Academic honesty:** Run the program yourself and use its measured output in your report. Do not submit invented or unverified observations.
